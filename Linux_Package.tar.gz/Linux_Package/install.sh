#!/bin/bash
# install.sh - Полный установщик для Linux (Debian/Ubuntu/Astra Linux)

set -e  # Завершить при ошибке

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${BLUE}[${1}/${2}]${NC} ${3}"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

# Проверка прав
if [ "$EUID" -ne 0 ]; then 
    print_error "Требуются права root. Запустите: sudo ./install.sh"
    exit 1
fi

echo "================================================"
echo "  Установка CLI системы распознавания документов"
echo "  для Linux (Debian/Ubuntu/Astra Linux)"
echo "================================================"
echo ""

# 1. ОБНОВЛЕНИЕ ПАКЕТОВ
print_step "1" "5" "Обновление пакетов системы..."
apt-get update -qq
apt-get upgrade -y -qq
print_success "Система обновлена"

# 2. УСТАНОВКА СИСТЕМНЫХ ЗАВИСИМОСТЕЙ
print_step "2" "5" "Установка системных зависимостей..."
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-venv \
    tesseract-ocr \
    tesseract-ocr-rus \
    tesseract-ocr-eng \
    poppler-utils \
    libgl1-mesa-glx \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libglib2.0-0

# Проверка установки Tesseract
if command -v tesseract &> /dev/null; then
    print_success "Tesseract установлен: $(tesseract --version | head -n1)"
else
    print_error "Tesseract не установился"
    exit 1
fi

# 3. СОЗДАНИЕ ВИРТУАЛЬНОГО ОКРУЖЕНИЯ
print_step "3" "5" "Создание виртуального окружения..."
VENV_PATH="/opt/dococr/venv"
INSTALL_DIR="/opt/dococr"

mkdir -p "$INSTALL_DIR"
python3 -m venv "$VENV_PATH"
source "$VENV_PATH/bin/activate"

print_success "Виртуальное окружение создано в $VENV_PATH"

# 4. УСТАНОВКА PYTHON ЗАВИСИМОСТЕЙ
print_step "4" "5" "Установка Python зависимостей..."
pip install --upgrade pip -q

if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt -q
else
    pip install pytesseract pdf2image Pillow PyPDF2 -q
fi

print_success "Python зависимости установлены"

# 5. УСТАНОВКА ПРОГРАММЫ
print_step "5" "5" "Установка программы..."

# Копируем скрипт
cp doc-processor "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/doc-processor"

# Создаем глобальный симлинк
ln -sf "$INSTALL_DIR/doc-processor" "/usr/local/bin/doc-processor"

# Копируем примеры если есть
if [ -d "examples" ]; then
    cp -r examples "$INSTALL_DIR/"
fi

# Копируем документацию
if [ -f "README.md" ]; then
    cp README.md "$INSTALL_DIR/"
fi

print_success "Программа установлена в $INSTALL_DIR"

# СОЗДАНИЕ КОНФИГУРАЦИОННОГО ФАЙЛА
cat > "$INSTALL_DIR/config.sh" << 'EOF'
#!/bin/bash
# Конфигурация DocOCR
export TESSERACT_CMD=$(which tesseract)
export POPPLER_PATH="/usr/bin"
export PYTHONPATH="/opt/dococr/venv/lib/python3.*/site-packages"
EOF

chmod +x "$INSTALL_DIR/config.sh"

# СОЗДАНИЕ ГРУППЫ ДЛЯ ЛОГОВ
if ! getent group dococr >/dev/null; then
    groupadd dococr
    print_success "Создана группа dococr для управления логами"
fi

# СОЗДАНИЕ ПАПКИ ДЛЯ ЛОГОВ
LOG_DIR="/var/log/dococr"
mkdir -p "$LOG_DIR"
chown -R root:dococr "$LOG_DIR"
chmod -R 775 "$LOG_DIR"

echo ""
echo "================================================"
echo "          УСТАНОВКА УСПЕШНО ЗАВЕРШЕНА!"
echo "================================================"
echo ""
echo "УСТАНОВЛЕНО:"
echo "  • Python 3 + виртуальное окружение"
echo "  • Tesseract OCR с русским и английским языками"
echo "  • Poppler utils (работа с PDF)"
echo "  • Все необходимые зависимости"
echo ""
echo "ПРОГРАММА УСТАНОВЛЕНА В:"
echo "  • Основная папка: $INSTALL_DIR"
echo "  • Исполняемый файл: /usr/local/bin/doc-processor"
echo "  • Логи: $LOG_DIR"
echo ""
echo "ИСПОЛЬЗОВАНИЕ:"
echo ""
echo "  1. Обработка одного документа:"
echo "     doc-processor single --input документ.pdf"
echo ""
echo "  2. Пакетная обработка:"
echo "     doc-processor batch --input-folder ./документы --output-folder ./результаты"
echo ""
echo "  3. Пропуск обработанных:"
echo "     doc-processor batch --input-folder ./документы --output-folder ./результаты --skip-existing"
echo ""
echo "  4. Справка:"
echo "     doc-processor --help"
echo ""
echo "  5. Примеры документов (если скопированы):"
echo "     ls $INSTALL_DIR/examples/"
echo ""
echo "================================================"